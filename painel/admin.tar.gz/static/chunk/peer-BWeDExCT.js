const c=t=>{let e=document.createElement("a");e.href=`expresschatremoto://${t}`,e.target="_self",e.click()};export{c};
