import{s as e}from"../entry/index-AdX7aN3E.js";function t(r){return e({url:"/my/peer/list",params:r})}export{t as l};
