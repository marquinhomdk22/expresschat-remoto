import{s as e}from"../entry/index-B7e3YbTz.js";function t(r){return e({url:"/my/peer/list",params:r})}export{t as l};
