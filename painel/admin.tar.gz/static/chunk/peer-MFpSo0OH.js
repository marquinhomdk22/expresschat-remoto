import{s as e}from"../entry/index-BAdeqVj5.js";function t(r){return e({url:"/my/peer/list",params:r})}export{t as l};
