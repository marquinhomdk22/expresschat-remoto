import{s as e}from"../entry/index-Sj9EE638.js";function t(r){return e({url:"/my/peer/list",params:r})}export{t as l};
